package com.example.recyclerview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements PersonAdapter.ItemClicked {

    RecyclerView recyclerview;
    RecyclerView.Adapter myAdapter;
    RecyclerView.LayoutManager layoutManager;
    Button btnAdd;

    ArrayList<Person> people;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerview=findViewById(R.id.list);
        recyclerview.setHasFixedSize(true);

        btnAdd=findViewById(R.id.btnAdd);
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                people.add(new Person("Susan","peters","bus"));
                myAdapter.notifyDataSetChanged();
            }
        });
        //layoutManager=new LinearLayoutManager(this);
        //layoutManager=new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false);
        layoutManager=new GridLayoutManager(this,2,GridLayoutManager.VERTICAL,false);
        recyclerview.setLayoutManager(layoutManager);

        people=new ArrayList<Person>();
        people.add(new Person("john","Rambo","bus"));
        people.add(new Person("john","Norris","bus"));
        people.add(new Person("Peter","Parker","aeroplane"));
        people.add(new Person("tom","cruise","aeroplane"));
        people.add(new Person("Akshay","Kumar","bus"));
        people.add(new Person("Narendra","modi","aeroplane"));
        people.add(new Person("Peter","Parker","aeroplane"));
        people.add(new Person("tom","cruise","aeroplane"));
        people.add(new Person("Akshay","Kumar","bus"));
        people.add(new Person("Narendra","modi","aeroplane"));
        people.add(new Person("Peter","Parker","aeroplane"));
        people.add(new Person("tom","cruise","aeroplane"));
        people.add(new Person("Akshay","Kumar","bus"));
        people.add(new Person("Narendra","modi","aeroplane"));

        myAdapter=new PersonAdapter(this,people);

        recyclerview.setAdapter(myAdapter);
    }

    @Override
    public void onItemClicked(int index) {

        Toast.makeText(this,"Surname: "+people.get(index).getSurname(),Toast.LENGTH_SHORT).show();
    }
}

package com.example.intentschallenge;

import android.content.Intent;
import android.net.Uri;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button btnNew;
    ImageView ivmood;
    ImageView ivcall;
    ImageView ivweb;
    ImageView ivlocation;
    final int detail=1;

    String name="",no="",web="",loc="",mood="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnNew=findViewById(R.id.btnNew);
        ivmood=findViewById(R.id.ivmood);
        ivcall=findViewById(R.id.ivcall);
        ivweb=findViewById(R.id.ivweb);
        ivlocation=findViewById(R.id.ivlocation);

        ivmood.setVisibility(View.GONE);
        ivcall.setVisibility(View.GONE);
        ivweb.setVisibility(View.GONE);
        ivlocation.setVisibility(View.GONE);

        btnNew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent= new Intent(MainActivity.this,
                        com.example.intentschallenge.Detail.class);
                startActivityForResult(intent,detail);

            }
        });

        ivcall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:"+no));
                startActivity(intent);

            }
        });

        ivweb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://"+web));
                startActivity(intent);
            }
        });

        ivlocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q="+loc));
                startActivity(intent);
            }
        });
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        if(requestCode==detail)
        {
            if(resultCode==RESULT_OK)
            {
                ivmood.setVisibility(View.VISIBLE);
                ivcall.setVisibility(View.VISIBLE);
                ivweb.setVisibility(View.VISIBLE);
                ivlocation.setVisibility(View.VISIBLE);

                 name=data.getStringExtra("name");
                 no = data.getStringExtra("phn");
                web=data.getStringExtra("web");
                 loc=data.getStringExtra("loc");
                 mood=data.getStringExtra("mood");

                if(mood.equals("happy"))
                {
                    ivmood.setImageResource(R.drawable.happy);
                }
                else if (mood.equals("neutral"))
                {
                    ivmood.setImageResource(R.drawable.neutral);
                }
                else
                    if(mood.equals("sad"))
                    {
                    ivmood.setImageResource(R.drawable.sad);
                }

            }

            else
            {
                Toast.makeText(this,"no data found",Toast.LENGTH_SHORT).show();
            }

        }

    }
}
